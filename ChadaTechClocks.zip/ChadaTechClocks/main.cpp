/*
Jessica Henry
Chada Tech Clocks
CS-210
07/19/25
*/

//Create the main program stream and functions used
#include <iostream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

//Returns a two-digit number with one-digit input
string FormatTwoDigit(int userNum){

	//Outputs two-digit number if only one digit
	stringstream twoDigNum;
	twoDigNum << setfill ('0') << setw(2) << userNum;
	return twoDigNum.str();
}

//Repeats a character a designated number of times
void RepeatSymbol(int numTimes, char newSymbol){
	for (int i = 0; i < numTimes; ++i){
		cout << newSymbol;
	}
}

//Outputs a 24-hour time format
string LongTimeFormat (int hours, int minutes, int seconds){
	string longTime;
	longTime = FormatTwoDigit(hours) + ":" + FormatTwoDigit(minutes) + ":" + FormatTwoDigit(seconds);
	return longTime;
}

//Outputs a 12-hour time format
string ShortTimeFormat (int hours, int minutes, int seconds){
	string shortTime;
	if(hours == 0){
		shortTime = FormatTwoDigit(hours + 12) + ":" + FormatTwoDigit(minutes) + ":" + FormatTwoDigit(seconds) + " AM";
	}
	else if(hours < 13){
		shortTime = FormatTwoDigit(hours) + ":" + FormatTwoDigit(minutes) + ":" + FormatTwoDigit(seconds) + " AM";	
	}
	else{
		shortTime = FormatTwoDigit(hours - 12) + ":" + FormatTwoDigit(minutes) + ":" + FormatTwoDigit(seconds) + " PM";
	}
	
	return shortTime;
}

//Prints menu choices
void PrintMenu(){
	RepeatSymbol(26, '*');
	cout << endl;
	cout << "* 1 - Add One Hour";
	RepeatSymbol(7, ' ');
	cout << "*" << endl;
	cout << "* 2 - Add One Minute";
	RepeatSymbol(5, ' ');
	cout << "*" << endl;
	cout << "* 3 - Add One Second";
	RepeatSymbol(5, ' ');
	cout << "*" << endl;
	cout << "* 4 - Exit Program";
	RepeatSymbol(7, ' ');
	cout << "*" << endl;
	RepeatSymbol(26, '*');
	cout << endl;
}

//Add an hour to the clocks
int AddHour (int hours){
	int newHours;

	newHours = hours + 1;

	if (newHours == 24){
		newHours = 0;
	}

	return newHours;
}

//Add a minute to the clocks
int AddMinute (int minutes){
	int newMinutes;

	newMinutes = minutes + 1;

	if (newMinutes == 60){
		newMinutes = 0;
	}

	return newMinutes;
}

//Add a second to the clocks
int AddSecond (int seconds){
	int newSeconds;

	newSeconds = seconds + 1;

	if (newSeconds == 60){
		newSeconds = 0;
	}
	return newSeconds;
}

//Reads user input from menu choices
int UserInputUpdate (int userInput, int timeToUpdate){

	//Adds an hour if input is 1
	if (userInput == 1){
		return AddHour(timeToUpdate);
	}

	//Adds a minute if input is 2
	else if (userInput == 2){
		return AddMinute(timeToUpdate);
	}

	//Adds a second if input is 3
	else if (userInput == 3){
		return AddSecond(timeToUpdate);
	}

	//Exits if input is 4
	else if (userInput == 4){
		cout << "You are now exiting the program." << endl;
		exit(0);
	}

	//Restarts loop if invalid input
	else{
		while (userInput < 1 || userInput > 4){
			cout << "That is not a valid input." << endl;
			PrintMenu();
			cin >> userInput;
		}
		return UserInputUpdate(userInput, timeToUpdate);
	}
}

//Displays both clocks
void ClockDisplay (int hours, int minutes, int seconds){

	//Use RepeatSymbol function to repeat redundant portions of clock interface
	RepeatSymbol(26, '*');
	RepeatSymbol(4, ' ');
	RepeatSymbol(26, '*');
	cout << endl;

	cout << "*";
	RepeatSymbol(5, ' ');
	cout << "12-Hour Clock";
	RepeatSymbol(5, ' ');
	cout << "*";
	RepeatSymbol(4, ' ');
	cout << "*";
	RepeatSymbol(5, ' ');
	cout << "24-Hour Clock";
	RepeatSymbol(5, ' ');
	cout << "*" << endl;

	//Use nested clock functions to output both up-to-date clocks
	cout << "*";
	RepeatSymbol(7, ' ');
	cout << ShortTimeFormat(hours, minutes, seconds);
	RepeatSymbol(5, ' ');
	cout << "*";
	RepeatSymbol(4, ' ');
	cout << "*";
	RepeatSymbol(7, ' ');
	cout << LongTimeFormat(hours, minutes, seconds);
	RepeatSymbol(7, ' ');
	cout << "*" << endl;

	RepeatSymbol(26, '*');
	RepeatSymbol(4, ' ');
	RepeatSymbol(26, '*');
	cout << endl;

	
}


int main(){

	//Gets initial time on clock from user
	int hours;
	int minutes;
	int seconds;

	cout << "Enter hours in military time:";
	cin >> hours;

	//Ensures user enters integer between 0 and 23
	while (!((hours >= 0) && (hours < 24))){
		if (hours < 0 || hours >= 24){
			cout << "Not a valid number. Please enter a number between 0 and 23." << endl;
			cin >> hours;
		}
		else{
			cout << "Not a valid input. Please enter an integer between 0 and 23." << endl;
			cin >> hours;
		}
	}

	cout << "Enter minutes:";
	cin >> minutes;

	//Ensures user enters integer between 0 and 59
	while (!((minutes >= 0) && (minutes < 60))){
		if (minutes < 0 || minutes >= 60){
			cout << "Not a valid number. Please enter a number between 0 and 59." << endl;
			cin >> minutes;
		}
		else{
			cout << "Not a valid input. Please enter an integer between 0 and 59." << endl;
			cin >> minutes;
		}
	}

	cout << "Enter seconds:";
	cin >> seconds;

	//Ensures user enters integer between 0 and 59
	while (!((seconds >= 0) && (seconds < 60))){
		if (seconds < 0 || seconds >= 60){
			cout << "Not a valid number. Please enter a number between 0 and 59." << endl;
			cin >> seconds;
		}
		else{
			cout << "Not a valid input. Please enter an integer between 0 and 59." << endl;
			cin >> seconds;
		}
	}

	//Display clock after original input
	ClockDisplay(hours, minutes, seconds);

	//Show user the menu
	PrintMenu();

	//Get user input from menu choices in loop until exit
	int userInput;
	cin >> userInput;

	if (userInput == 1){
		hours = UserInputUpdate(userInput, hours);
	}
	else if (userInput == 2){
		minutes = UserInputUpdate(userInput, minutes);
		if (minutes == 0){
			hours = AddHour(hours);
		}
	}
	else if (userInput == 3){
		seconds = UserInputUpdate(userInput, seconds);
		if (seconds == 0){
			minutes = AddMinute(minutes);
			if (minutes == 0){
				hours = AddHour(hours);
			}
		}
	}
	else{
		UserInputUpdate(userInput, 0);
	}

	//Loop until user quits program
	//Display menu and clock after each update
	while(userInput != 4){
		ClockDisplay(hours, minutes, seconds);
		PrintMenu();
		cin >> userInput;
		
		//Update based on user input
		if (userInput == 1){
			hours = UserInputUpdate(userInput, hours);
		}
		else if (userInput == 2){
			minutes = UserInputUpdate(userInput, minutes);
			if (minutes == 0){
				hours = AddHour(hours);
			}
		}
		else if (userInput == 3){
			seconds = UserInputUpdate(userInput, seconds);
			if (seconds == 0){
				minutes = AddMinute(minutes);
				if (minutes == 0){
					hours = AddHour(hours);
				}
			}
		}
		else{
			UserInputUpdate(userInput, 0);
		}
	}

	//Exits program
	return 0;
}